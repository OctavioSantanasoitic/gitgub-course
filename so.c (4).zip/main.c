
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

main()
{
     int descritor;  // usado para criar o processo filho pelo fork
     int pipe1[2];  // comunicacao pai -> filho
     int pipe2[2]; // comunicacao filho -> pai
     int contas[3];
     int resultado[1];  
   
   if (pipe(pipe1)<0 || pipe(pipe2) <0)
   {     
      printf("Erro na chamada PIPE");
      exit(0);
   }
   //   Fork para criar o processo filho
    if ( (descritor = fork()) <0)
   {       
      printf("Erro na chamada FORK");
      exit(0);
   }
  else if (descritor >0)  // PROCESSO PAI
   {   
     close(pipe1[0]); // fecha leitura no pipe1
     close(pipe2[1]);  // fecha escrita no pipe2
     conta(pipe2[0], pipe1[1],contas);  // Chama Conta no PAI
     close(pipe1[1]); // fecha pipe1
     close(pipe2[0]);  // fecha pipe2
     exit(0);
   } // FIM DO PROCESSO PAI
 else // PROCESSO FILHOo
    { 
      close(pipe1[1]); // fecha escrita no pipe1
      close(pipe2[0]);  // fecha leitura no pipe2
      resolve(pipe1[0], pipe2[1], resultado);  // Chama Resolve no FILHO
      close(pipe1[0]); // fecha leitura no pipe1
      close(pipe2[1]);  // fecha escrita no pipe2
      exit(0);
    } // FIM DO PROCESSO FILHO
} // FIM DO MAIN
/* 
-----------------------------------------------------------------------------------
------------------------
Funcao Conta:  Executa no processo PAI
Envia o nome do arquivo para o FILHO
Recebe os dados do FILHO e imprime na tela
-----------------------------------------------------------------------------------
------------------------ */
conta(readfd, writefd, contas)
int readfd, // leitura do pipe2[0]
    writefd;// escrita no pipe1[1]
   int contas[3];
{
    int resultado[3];
    int opt;
    int aux = 0;

        
      while(1)
       { 
           if(aux == 0)
           
            {
           printf("\n\nInicializando Calculadora Pipe Simples. Pressione a tecla enter para continuar");
           printf("\n............................................................\n");
           getchar();
           aux++;
            }
            
            else
              {
           printf("\n\nInicializando Calculadora Pipe Simples");
           printf("\n............................................................\n"); 
              }
           printf(" \n Digite o primeiro numero->");
           scanf("%d", &contas[0]);
           printf(" \n Digite o segundo numero->");
           scanf("%d", &contas[1]);
           printf(" \n Digite o operador->");
           scanf("%d", &contas[2]);


write(writefd, contas, 10);
read(readfd, resultado, 10);
printf("Resultado: %d\n\n", resultado[1]);
printf("Deseja continuar ou gostaria de sair? 1 para sair ou qualquer tecla para continuar: ");
fflush(stdin);
scanf("%d", &opt);
if(opt == 1)
    exit(1);

       } 
       
  } // Fim da Funcao Conta
/* 
-----------------------------------------------------------------------------------
------------------------
Funcao Resolve:  Executa no processo FILHO
Abre o arquivo solicitado e envia seu conteudo
para o PAI
-----------------------------------------------------------------------------------
------------------------ */
resolve(readfd, writefd, resultado)
int readfd, // leitura do pipe1[0]
    writefd; // escrita no pipe2[1]
    int resultado[3]; 
{
int resultado1; 
int contas[3];
while(1)
          {
        read(readfd,contas,10);
printf(" \n Primeiro Numero <- %d",contas[0]);
printf(" \n Segundo Numero <- %d",contas[1]);
printf(" \n Operador <- %d",contas[2]);

if(contas[2] == 1)
    {
    printf("\n ****** Operacao de soma foi selecionada com sucesso! ******\n");
    resultado1 = contas[0] + contas[1]; 
    }    
   
   if(contas[2] == 2)
     {
    printf("\n****** Operacao de subtracao foi selecionada com sucesso! ******\n");
    resultado1 = contas[0] - contas[1]; 
     }
    
    if(contas[2] == 3)
    {
    printf("\n****** Operacao de multiplicacao foi selecionada com sucesso! ******\n");
    resultado1 = contas[0] * contas[1]; 
    }
    
    if(contas[2] == 4)
    {
    printf("\n****** Operacao de divisao foi selecionada com sucesso! ******\n");
    resultado1 = contas[0] / contas[1]; 
    }

             
 
 resultado[1] = resultado1;
write(writefd, resultado, 10);

            } 
            
            
    } // Fim da Funcao Resolve



